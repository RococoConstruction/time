const CACHE_NAME = 'rcs-time-v1';
const STATIC_ASSETS = ['/time/', '/time/index.html'];

// Install - cache static assets
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(STATIC_ASSETS))
  );
  self.skipWaiting();
});

// Activate - clean old caches
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// Fetch strategy:
// - Google Sheets API calls: always network (never cache)
// - App shell: network first, fall back to cache
self.addEventListener('fetch', event => {
  const url = event.request.url;

  // Never cache Google Sheets/Script calls
  if (url.includes('script.google.com') || url.includes('googleapis.com')) {
    event.respondWith(fetch(event.request));
    return;
  }

  // Network first for the app itself
  event.respondWith(
    fetch(event.request)
      .then(response => {
        const clone = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
        return response;
      })
      .catch(() => caches.match(event.request))
  );
});

// Listen for skip waiting message from app
self.addEventListener('message', event => {
  if (event.data === 'skipWaiting') self.skipWaiting();
});
